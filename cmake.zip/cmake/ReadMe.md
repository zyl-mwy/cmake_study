## Source
[bilibili——CMake 保姆级教程【C/C++】——爱编程的大丙](https://www.bilibili.com/video/BV14s4y1g7Zj?spm_id_from=333.788.videopod.episodes&vd_source=ee200f7e09eb8dbc8631c991d8917853&p=2)

[对应文档](https://subingwen.cn/cmake/CMake-primer)

## Demo
### demo_00: 编写一个简单的CMakeLists.txt
* cmake 查看版本
```bash
cmake --version
```

* 直接编译 运行
```bash
g++ *.cpp -o app

./app
```

* 创建 CMakeLists.txt
```bash
touch CMakeLists.txt
```

* 编译 cmake
```bash
cmake .

cmake ..
```

* 查看文件树
```bash
tree
```

* 执行 make
```bash
make
```

* 看起来不乱
```bash
mkdir build

cd build

cmake ..

make

./app
```

### demo_01：CMake 中 set 的使用
* cmake 如果没有在txt里声明c++版本，则可以这样执行编译命令
```bash
cmake . -DCMAKE_CXX_STANDARD=11
```

* 显示当前目录路径
```bash 
pwd
```

### demo_02: 搜索文件

### demo_03: 指定头文件路径

### demo_04: 通过 cmake 制作库文件

### demo_05: 在程序中链接动态库

### demo_06: 在程序中链接动态库

### demo_07: 在 cmake 中打印日志信息

### demo_08: 字符串操作

### demo_09: 自定义宏

### demo_10: 嵌套的 cmake

### demo_11: 在静态库中链接静态库

### demo_12: 在静态库中链接动态库

### demo_13: 实例
* target_link_libraries 既可以链接静态库，也可以链接动态库