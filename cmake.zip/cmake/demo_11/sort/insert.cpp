// #include <stdio.h>
// #include "sort.h"
#include <iostream>
#include <stdio.h>

#include "calc.h"
using namespace std;

// const char* libVersion = "Library Version 1.0";

int insert(int a, int b)
{
    int number = add(a, b);
    cout << number << endl;
    return a+b;
}