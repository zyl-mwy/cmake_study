#include <stdio.h>
#include "sort.h"

// const char* libVersion = "Library Version 1.0";

int insert(int a, int b)
{
    return a+b;
}