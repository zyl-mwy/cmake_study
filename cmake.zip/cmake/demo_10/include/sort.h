#ifndef _SORT_H
#define _SORT_H

int insert(int a, int b);

int select(int a, int b);

#endif