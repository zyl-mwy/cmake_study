#include <stdio.h>
#include "sort.h"

int main()
{
    int a = 20;
    int b = 12;
    printf("a = %d, b = %d\n", a, b);
    printf("a + b = %d\n", insert(a, b));
    printf("a - b = %d\n", insert(a, b));
    printf("a * b = %d\n", select(a, b));
    printf("a / b = %d\n", select(a, b));
    return 0;
}