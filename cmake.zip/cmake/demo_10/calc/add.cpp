#include <stdio.h>
#include "calc.h"

// const char* libVersion = "Library Version 1.0";

int add(int a, int b)
{
    return a+b;
}